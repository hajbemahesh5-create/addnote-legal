# AddNote Legal Pages

Public Privacy Policy and Terms of Service for the AddNote Android app.

## Publish with GitHub Pages
1. Create a **public** repository named `addnote-legal` on your GitHub account.
2. Upload `index.html`, `privacy-policy.html`, `terms.html`, and `style.css` to the repository root (not inside an enclosing folder).
3. Repository **Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save**.
4. After publishing, verify both pages open in an incognito window:
   - `https://hajbemahesh5-create.github.io/addnote-legal/privacy-policy.html`
   - `https://hajbemahesh5-create.github.io/addnote-legal/terms.html`
5. Add the exact verified links to Play Console and your RevenueCat paywall. Do not use these links until Pages is live.

## Review before publishing
- Contact email is `hajbemahesh5@gmail.com` (visible in the connected GitHub profile); replace with the app's designated public support email if different.
- Check that data practices match the current shipped APK/AAB and the AdMob/RevenueCat SDKs actually included.
- Review age-targeting, consent, backup, permissions, and subscription benefits. Adapt the documents when product behavior changes.
- This is a practical draft, not jurisdiction-specific legal advice.
